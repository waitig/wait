<?php
get_header();
theme_check();
?>
