<?php get_header();

/*
		template name: 测试页面
	description: template for waitig.com waitig theme 
*/
theme_check();


get_footer(); ?>
